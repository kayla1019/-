/*var array = [];
let sum=0;
var a;

for(a=0;a<5;a++){
    array.push(a+1);
}

for(a=0;a<5;a++){
    sum+=array[a];
}
console.log(sum);
*/

var readline = require('readline');
var r = readline.createInterface({
    input : process.stdin,
    output : process.stdout
});

var array=[];
var a=0;

r.on("line", function(result) {
    if(result == 'q') {
        r.close();
    }

    array.push(result);
    a++;

    if(a == 5) {
        array.sort();

        for(var i = 0; i < 5; i++) {
            console.log(array[i] + " ");
        }
    }
});

// for(a=0;a<4;a++){
//     input("%d", array[a]);
// }

// array.sort();

// for(a=0;a<5;a++){
//     console.log(array[a]+' ');
// }


